package hello.login.domain.item;

public interface SaveCheck {
}